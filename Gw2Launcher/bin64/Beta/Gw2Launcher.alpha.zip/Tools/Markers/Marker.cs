using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Gw2Launcher.Tools.Markers
{
    class Marker
    {
        public static void Draw(Graphics g, Settings.IMarker marker)
        {

        }
    }
}
